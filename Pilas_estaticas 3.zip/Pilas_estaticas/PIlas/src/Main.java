import Implementacion.*;
import Interfaces.PilaTDA;

public class Main {
    public static void main(String[] args) {

        PilaTDA p1 = new Estrategia_1();
        /* PilaTDA p2 = new Estrategia_2();
         PilaTDA p3 = new Estrategia_3(); */

        probarPila("Estrategia 1", p1);
         /* probarPila("Estrategia 2", p2);
         probarPila("Estrategia 3", p3); */
    }

    public static void probarPila(String nombre, PilaTDA pila) {
        System.out.println("=== " + nombre + " ===");

        pila.InicializarPila();

        pila.Apilar("fi.uba.ar");
        pila.Apilar("campus.utn.ar");
        pila.Apilar("stackoverflow.com");

        System.out.println("Tope luego de apilar los links: " + pila.Tope());

        pila.Desapilar();
        System.out.println("Tope luego de desapilar una vez: " + pila.Tope());

        pila.Desapilar();
        System.out.println("Tope luego de desapilar otra vez: " + pila.Tope());

        pila.Desapilar();
        System.out.println("¿Pila vacía?: " + pila.PilaVacia());

        System.out.println();

        // PRUEBA DE BALANCEO
        String expresion = "( ( a + b ) * c )";

        if (BalanceoParentesis.esBalanceado(expresion)) {
            System.out.println("La expresión está balanceada");
        } else {
            System.out.println("La expresión NO está balanceada");
        }
        System.out.println();

        String palabra = "ALGORITMOS";
        String invertida = InvertirString.invertir(palabra, pila);

        System.out.println("Original: " + palabra);
        System.out.println("Invertida: " + invertida);

        System.out.println();

        String[] estados = {
                "Linea 1",
                "Linea 1\nLinea 2",
                "Linea 1\nLinea 2\nLinea 3"
        };
        String actual = EditorTexto.deshacer(estados, pila);
        System.out.println("Estado actual luego de undo:\n" + actual);

        System.out.println();

        String funcionActual = CallStack.ejecutarLlamadas(pila);
        System.out.println("Función en ejecución: " + funcionActual);
        System.out.println();

        String carpetaActual = NavegarDirectorios.subirNivel(pila);
        System.out.println("Carpeta actual: " + carpetaActual);
        System.out.println();

        System.out.println("\n---------------------Respuestas a las preguntas de la consigna-----------------------\n");


        System.out.println("Pregunta 1: Cada vez que el usuario visita una página, la pagina web se apila en la pila. y al apretar la flewcha para atras esta ultima se desapila y se muestra la pagina anterior");
        System.out.println("pregunta 2: Cada vez que el usuario realiza un cambio, se apila el estado completo del código. cuando se utiliza el undo, se desapila el ultimo estado y se vuelve al estado anterior ");
        System.out.println("pregunta 3:Cada vez que se encuentra un paréntesis de apertura \"(\", se hace un apilar.Cada vez que se encuentra un paréntesis de cierre \")\", se compara con el tope y luego se desapila.\n Al finalizar, la pila queda vacía, lo que indica que la expresión está balanceada.");
        System.out.println("pregunta 4: Se apilan las letras de la palabra \"ALGORITMOS\" una por una: Pila: [A, L, G, O, R, I, T, M, O, S]\nLuego se desapilan en orden inverso:  S, O, M, T, I, R, O, G, L, A");
        System.out.println("pregunta 5: Las llamadas se apilan de la siguiente forma: [Main, CalcularPromedio, Sumar]. El tope de la pila es Sumar(), ya que es la función que se está ejecutando en ese momento.\n" +"Cuando termina: Se desapila Sumar y se vuelve a CalcularPromedio");
        System.out.println("pregunta 6: Cada vez que se entra a una carpeta, se apila:[C:/, Usuarios, Documentos] Cuando se presiona \"Subir un nivel\": se desapila Documentos y se vuelve a Usuarios. Si se presiona \"Subir un nivel\" nuevamente, se desapila Usuarios y se vuelve a C:/");
    }
}