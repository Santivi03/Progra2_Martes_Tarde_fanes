package Implementacion;

import Interfaces.PilaTDA;

public class NavegarDirectorios {

    public static String subirNivel(PilaTDA pila) {
        pila.InicializarPila();

        pila.Apilar("C:/");
        pila.Apilar("Usuarios");
        pila.Apilar("Documentos");

        // Simula "Subir un nivel"
        pila.Desapilar();

        return pila.Tope();
    }
}
