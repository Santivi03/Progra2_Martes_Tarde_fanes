package Implementacion;

import Interfaces.PilaTDA;

public class Estrategia_3 implements PilaTDA {

    private static final int MAX = 100;
    private String[] datos;

    @Override
    public void InicializarPila() {
        datos = new String[MAX + 1];
        datos[0] = "0"; // en la posición 0 se guarda la cantidad de elementos
    }

    @Override
    public void Apilar(String x) {
        int cantidad = Integer.parseInt(datos[0]);
        if (cantidad < MAX) {
            datos[0] = String.valueOf(cantidad + 1);
            datos[cantidad + 1] = x;
        }
    }

    @Override
    public void Desapilar() {
        if (!PilaVacia()) {
            datos[0] = String.valueOf(Integer.parseInt(datos[0]) - 1);        }
    }

    @Override
    public String Tope() {
        return datos[Integer.parseInt(datos[0])];
    }

    @Override
    public boolean PilaVacia() {
        return Integer.parseInt(datos[0]) == 0;
    }
}
