package Implementacion;

import Interfaces.PilaTDA;

public class CallStack {
    public static String ejecutarLlamadas(PilaTDA pila) {
        pila.InicializarPila();

        pila.Apilar("Main");
        pila.Apilar("CalcularPromedio");
        pila.Apilar("Sumar");

        return pila.Tope();
    }
}
