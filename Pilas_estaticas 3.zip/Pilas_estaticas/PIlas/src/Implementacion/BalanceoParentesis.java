package Implementacion;

public class BalanceoParentesis {

    public static boolean esBalanceado(String expresion) {
        Estrategia_1 pila = new Estrategia_1();
        pila.InicializarPila();

        for (char c : expresion.toCharArray()) {
            if (c == '(') {
                pila.Apilar(String.valueOf(c));
            } else if (c == ')') {
                if (pila.PilaVacia()) {
                    return false; // No hay paréntesis de apertura para este cierre
                }
                String tope = pila.Tope();
                if ((c == ')') && (!tope.equals("("))){
                    return false; // El paréntesis de cierre no coincide con el de apertura
                }
                pila.Desapilar();
            }
        }
        return pila.PilaVacia(); // Si la pila está vacía, todos los paréntesis están balanceados
    }
}
