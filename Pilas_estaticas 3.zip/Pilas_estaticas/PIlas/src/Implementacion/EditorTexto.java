package Implementacion;

import Interfaces.PilaTDA;

public class EditorTexto {
    public static String deshacer(String[] estados, PilaTDA pila) {
        pila.InicializarPila();


        for (int i = 0; i < estados.length; i++) {
            pila.Apilar(estados[i]);
        }

        if (!pila.PilaVacia()) {
            pila.Desapilar();
        }

        if (!pila.PilaVacia()) {
            return pila.Tope();
        }

        return null;
    }
}
