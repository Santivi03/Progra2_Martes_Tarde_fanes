package Implementacion;
import Interfaces.PilaTDA;

public class InvertirString {
        public static String invertir(String palabra, PilaTDA pila) {
            pila.InicializarPila();

            // Apilar
            for (int i = 0; i < palabra.length(); i++) {
                pila.Apilar(String.valueOf(palabra.charAt(i)));
            }

            // Desapilar
            String resultado = "";
            while (!pila.PilaVacia()) {
                resultado += pila.Tope();
                pila.Desapilar();
            }

            return resultado;
        }
}
