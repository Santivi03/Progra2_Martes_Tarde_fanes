import Implementacion.ColaEstatica;
import Interface.ColaTDA;

public class Main {
    public static void main(String[] args) {
        ColaTDA cola = new ColaEstatica();

        cola.InicializarCola();

        System.out.println("¿Cola vacía?: " + cola.ColaVacia());
// ejercicio 1
        cola.Acolar("persona 1");
        cola.Acolar("persona 2");
        cola.Acolar("persona 3");

        System.out.println("Primero: " + cola.Primero());

        cola.Desacolar();
        System.out.println("Primero luego de desacolar: " + cola.Primero()); 

        cola.Acolar("persona 4");
        System.out.println("Primero luego de acolar persona 4: " + cola.Primero()); 

        cola.Desacolar();
        System.out.println("Primero luego de desacolar: " + cola.Primero()); 

        cola.Desacolar();
        System.out.println("Primero luego de desacolar: " + cola.Primero()); 

        cola.Desacolar();
        System.out.println("¿Cola vacía?: " + cola.ColaVacia());

        // Ejercicio 2

        cola.Acolar("Archivo 1");
        cola.Acolar("Archivo 2");
        cola.Acolar("Archivo 3");
        cola.Acolar("Archivo 4");
        cola.Acolar("Archivo 5");

        System.out.println("Primero: " + cola.Primero());

        cola.Desacolar();
        System.out.println("Primero luego de desacolar: " + cola.Primero());

        cola.Desacolar();
        System.out.println("Primero luego de desacolar: " + cola.Primero());

        cola.Desacolar();
        System.out.println("Primero luego de desacolar: " + cola.Primero());

        cola.Desacolar();
        System.out.println("Primero luego de desacolar: " + cola.Primero());


        cola.Desacolar();
        System.out.println("¿Cola vacía?: " + cola.ColaVacia());



    }
}