import Implementacion.ConjuntoEstatico;
import Interface.ConjuntoTDA;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        ConjuntoTDA c = new ConjuntoEstatico();

        c.InicializarConjunto();

        System.out.println("¿Conjunto vacío?: " + c.ConjuntoVacio());

        c.Agregar(3);
        c.Agregar(7);
        c.Agregar(3); // no debe repetirse
        c.Agregar(10);

        System.out.println("¿Pertenece 3?: " + c.Pertenece(3));
        System.out.println("¿Pertenece 5?: " + c.Pertenece(5));

        System.out.println("Elemento elegido: " + c.Elegir());

        c.Sacar(7);
        System.out.println("¿Pertenece 7 luego de sacarlo?: " + c.Pertenece(7));

        c.Sacar(3);
        System.out.println("¿Pertenece 3 luego de sacarlo?: " + c.Pertenece(3));

        System.out.println("¿Conjunto vacío?: " + c.ConjuntoVacio());

        // Padrón electoral -------------------------------------------------
        ConjuntoTDA padronVotaron = new ConjuntoEstatico();
        padronVotaron.InicializarConjunto();
        int dniVotante = 40123456;

        if (padronVotaron.Pertenece(dniVotante)) {
            System.out.println("¡Alerta! Este vivo ya votó.");
        } else {
            System.out.println("Podés votar.");
            padronVotaron.Agregar(dniVotante); // Lo anotamos para que no vuelva a votar
        }

        // Invitados a la Fiesta de Fin de Cursada -------------------------------------------------
        ConjuntoTDA invitados = new ConjuntoEstatico();
        invitados.InicializarConjunto();
        int idInvitado = 10;
        // Agregamos al invitado
        invitados.Agregar(idInvitado);
        // Intentamos agregarlo por segunda vez
        invitados.Agregar(idInvitado);
        invitados.Sacar(idInvitado);

        System.out.println("¿El invitado 10 sigue en la lista tras sacarlo una vez?: " + invitados.Pertenece(idInvitado));
        // Imprime false. Esto demuestra que la segunda operación Agregar(10) fue ignorada por completo.

        // Filtro de Spam (Blacklist) -------------------------------------------------
        // Asumimos que 1=Crypto, 2=Ganá, 3=Premio
        ConjuntoTDA blacklist = new ConjuntoEstatico();
        blacklist.InicializarConjunto();
        blacklist.Agregar(1);
        blacklist.Agregar(2);

        int[] palabrasDelMail = {15, 84, 1, 99};

        boolean esSpam = false;
        for (int i = 0; i < palabrasDelMail.length; i++) {
            if (blacklist.Pertenece(palabrasDelMail[i])) {
                esSpam = true;
                System.out.println("¡Spam detectado! Palabra prohibida encontrada: ID " + palabrasDelMail[i]);
                break;
            }
        }

        // Tags de un Blog de Ingeniería -------------------------------------------------
        ConjuntoTDA tagsDePost = new ConjuntoEstatico();
        tagsDePost.InicializarConjunto();

        int idTagJava = 100; // Representa "#Java"
        int idTagOOP = 101;  // Representa "#OOP"

        tagsDePost.Agregar(idTagJava);
        tagsDePost.Agregar(idTagOOP);

        // Se agrega la etiqueta "#Java" 2 veces
        tagsDePost.Agregar(idTagJava);

        System.out.println("¿El tag OOP pertenece?: " + tagsDePost.Pertenece(idTagOOP));
        System.out.println("¿El tag Java pertenece?: " + tagsDePost.Pertenece(idTagJava));

        // Gestión de Legajos -------------------------------------------------
        ConjuntoTDA baseDeDatosLegajos = new ConjuntoEstatico();
        baseDeDatosLegajos.InicializarConjunto();

        int legajoUnico = 5555;

        System.out.println("Inscribiendo alumno en Ing. Informática...");
        baseDeDatosLegajos.Agregar(legajoUnico);

        System.out.println("Inscribiendo al mismo alumno en Ing. en Sistemas...");
        baseDeDatosLegajos.Agregar(legajoUnico);

        System.out.println("¿El legajo 5555 está en la base de datos?: " + baseDeDatosLegajos.Pertenece(legajoUnico));

        // Operación Elegir vs Sacar -------------------------------------------------
        System.out.println("Si llamás a Elegir dos veces seguidas sin llamar a Sacar, ¿te devuelve el mismo elemento?");
        System.out.println("En este caso, por como está programado Elegir y al no llamar a Sacar, este siempre va a devolver lo que está en la primera posición del arreglo");

    }
}

